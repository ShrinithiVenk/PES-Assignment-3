/*
 * blinkled.h
 *
 */

#ifndef BLINKLED_H_
#define BLINKLED_H_
#include "MKL25Z4.h"
#include "board.h"
#include "peripherals.h"
#include "pin_mux.h"
#include "clock_config.h"
#include "fsl_debug_console.h"

#include "stdio.h"

/***********Declaring the functions****************/

void delay(int iterations);
void portInitialize(void);
void pinInitialize(void);
void muxIntialize(void);
void led_blink(int rgb);
void white_blink(int led);

/***********Defining macros****************/

#define RED_LED_PIN 18
#define GREEN_LED_PIN 19
#define BLUE_LED_PIN 1

#define MASK(x) (1UL << (x))

#define ONTIME 500000
#define OFFTIME 100000

#endif /* BLINKLED_H_ */
