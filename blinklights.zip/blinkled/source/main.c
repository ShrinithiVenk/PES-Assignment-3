/**************************
*​​Copyright​​ (C) ​​2022 ​​by Shrinithi
*​​Redistribution,​​ modification ​​or ​​use ​​of ​​this ​​software ​​in​​source​ ​or ​​binary
*​​forms​​ is​​ permitted​​ as​​ long​​ as​​ the​​ files​​ maintain​​ this​​ copyright.​​ Users​​ are
*​​permitted​​ to ​​modify ​​this ​​and ​​use ​​it ​​to ​​learn ​​about ​​the ​​field​​ of ​​embedded
*​​software. Shrinithi ​​and​ ​the ​​University ​​of ​​Colorado ​​are ​​not​ ​liable ​​for
*​​any ​​misuse ​​of ​​this ​​material.
*
**************************/
/**
 *
 * @author Shrinithi
 * @date September 24 2022
 * @version 1.0
 *
 *
  Sources of Reference:
  Online Links:
  https://github.com/alexander-g-dean/ESF/blob/master/NXP/Code/Chapter_2/Source/main.c
  https://github.com/alexander-g-dean/ESF/tree/master/NXP/Misc/Touch%20Sense
  i.e. Alexander G Dean's github repository for NXP KL25Z Touch Scan Slider
  Textbook: Embedded Systems Fundamentals with Arm Cortex-M based MicroControllers
*/

/**
 * @file    main.c
 * @brief   Application entry point.
 */
#include "blinkled.h"
#include "touch.h"
#include<stdio.h>
#include <stdbool.h>
#include<stdlib.h>

//Used as a delay function to get the minimum delay time between the touch interrupts.
int min_delay(int pollTime, int blink_delay)
{
	return pollTime>blink_delay? blink_delay:pollTime;
}

int main(void)

{
   //calling the functions
   portInitialize();
   pinInitialize();
   muxIntialize();

   int poll_time = 100; //Introducing poll time

   led_blink(1); //function for turning red led on and off
#ifdef DEBUG
   printf("RED blink once\n" );
#endif
   led_blink(2); //function for turning green led on and off
#ifdef DEBUG
   printf("GREEN blink once\n" );
#endif
   led_blink(3); //function for turning blue led on and off
#ifdef DEBUG
   printf("BLUE blink once\n" );
#endif
   white_blink(3); //function for turning white led on and off
#ifdef DEBUG
   printf("WHITE blink once\n" );
#endif

   touch_init();
   int blink_delay[4] = {500,1000,2000,3000}; //array holding delay values
   int count = 0; //initializing count to 0
   bool touch = false; //when touch set false, the loop sequence continues
   while(!touch)
   {
   white_blink(1); //turn on white led
   delay(blink_delay[count]); //blink led in the array sequence
   white_blink(2); //turn off white led
   delay(blink_delay[0]); //off for 500ms
   count = count < 3? count+1 : 0; //looping the array delay sequence
   touch = touch_val_scan()<=10? false:true; //exit loop when interrupt occurs
#ifdef DEBUG
   printf("The white LED loop \n" );
#endif
   }
   count = 0;
   int val = 0;
   int touchVal = 0;
   int remTime = 0;
   white_blink(1);
   while(1)
   {
   remTime = blink_delay[count];
#ifdef DEBUG
   printf("Timer value %d\n",remTime );
#endif
   //for On
   while(remTime>0){
   val = touch_val_scan();
   touchVal = val<=100 ? touchVal : val;
   //left -> Red
   if(touchVal>=100 && touchVal<=400){
	   white_blink(2); //clear the white led off
       GPIOB->PCOR |= MASK(RED_LED_PIN); //turn on red led
#ifdef DEBUG
       printf("The Red LED loop \n" );
#endif
   }
   //Center -> Green
   else if(touchVal>=400 && touchVal<=1000){
	   white_blink(2); //clear the white led off
       GPIOB->PCOR |= MASK(GREEN_LED_PIN); //turn on green led
#ifdef DEBUG
       printf("The Green LED loop \n" );
#endif
   }
    //Right -> Blue
    else if(touchVal>=1000){
       white_blink(2); //clear the white led off
       GPIOD->PCOR |= MASK(BLUE_LED_PIN); //turn on blue led
#ifdef DEBUG
       printf("The Blue LED loop \n" );
#endif
    }
   // Getting minimal delay response to touch interrupt while led is in blinking operation loop.
   delay(min_delay(poll_time, remTime));
   remTime -= min_delay(poll_time,remTime);
   }
   //for OFF
   for (int x=0;x<5;x++){
       val = touch_val_scan();
       touchVal = val<=100 ? touchVal : val;
       //left -> Red
       if(touchVal>=100 && touchVal<=500){
           GPIOB->PSOR |= MASK(RED_LED_PIN); //turn off red led
       }
       //Center -> Green
       else if(touchVal>=500 && touchVal<=1100){
           GPIOB->PSOR |= MASK(GREEN_LED_PIN); //turn off green led
       }
       //right -> Blue
       else if(touchVal>=1100){
           GPIOD->PSOR |= MASK(BLUE_LED_PIN); //turn off blue led
       }
       delay(poll_time);
       }
       count = count < 3? count+1 : 0; //looping the array delay sequence
   }
}
