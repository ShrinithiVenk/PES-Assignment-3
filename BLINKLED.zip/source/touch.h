/*
 * touch.h
 *
 */

#ifndef TOUCH_H_
#define TOUCH_H_
#include "stdio.h"
#include "MKL25Z4.h"

/***********Defining macros****************/

#define TOUCH_OFFSET 572
#define TOUCH_COUNT ((TSI0->DATA)& 0XFFFF)

/***********Declaring the functions****************/

void touch_init();
int touch_val_scan(void);
void delay(int iterations);


#endif /* TOUCH_H_ */
