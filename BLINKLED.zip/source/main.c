/**************************
*​​Copyright​​ (C) ​​2022 ​​by Shrinithi
*​​Redistribution,​​ modification ​​or ​​use ​​of ​​this ​​software ​​in​​source​ ​or ​​binary
*​​forms​​ is​​ permitted​​ as​​ long​​ as​​ the​​ files​​ maintain​​ this​​ copyright.​​ Users​​ are
*​​permitted​​ to ​​modify ​​this ​​and ​​use ​​it ​​to ​​learn ​​about ​​the ​​field​​ of ​​embedded
*​​software. Shrinithi ​​and​ ​the ​​University ​​of ​​Colorado ​​are ​​not​ ​liable ​​for
*​​any ​​misuse ​​of ​​this ​​material.
*
**************************/
/**
 *
 * @author Shrinithi
 * @date September 24 2022
 * @version 1.0
 *
 *
  Sources of Reference:
  Online Links:
  https://github.com/alexander-g-dean/ESF/blob/master/NXP/Code/Chapter_2/Source/main.c
  https://github.com/alexander-g-dean/ESF/tree/master/NXP/Misc/Touch%20Sense
  i.e. Alexander G Dean's github repository for NXP KL25Z Touch Scan Slider
  Textbook: Embedded Systems Fundamentals with Arm Cortex-M based MicroControllers
*/

/**
 * @file    main.c
 * @brief   Application entry point.
 */

#include "blinkled.h"
#include "touch.h"
#include<stdio.h>
#include <stdbool.h>
#include<stdlib.h>

int led;
int rgb;

int main(void)

{
   //calling the functions
   portInitialize();
   pinInitialize();
   muxIntialize();

   led_blink(1); //function for turning red led on and off
   led_blink(2); //function for turning green led on and off
   led_blink(3); //function for turning blue led on and off
   white_blink(3); //function for turning white led on and off

   touch_init();
   int blink[4] = {500000,1000000,2000000,3000000}; //array holding delay values
   int count = 0; //initializing count to 0
   bool touch = false; //when touch set false, the loop sequence continues
   while(!touch){

                   white_blink(1); //turn on white led
                   delay(blink[count]); //blink led in the array sequence
                   white_blink(2); //turn off white led
                   delay(blink[0]); //off for 500ms
                   count = count < 3? count+1 : 0; //looping the array delay sequence
                   touch = touch_val_scan()<=10? false:true; //exit loop when interrupt occurs

   }
   count = 0;
   int val = 0;
   int touchVal = 0;
   white_blink(2);
   while(1){
        val = touch_val_scan();
        touchVal = val<=100 ? touchVal : val;
            //left -> Red
            if(touchVal>=100 && touchVal<=500){

        	white_blink(2); //clear the white led off
            GPIOB->PCOR |= MASK(RED_LED_PIN); //turn on red led
            delay(blink[count]); //blink in the array sequence
            GPIOB->PSOR |= MASK(RED_LED_PIN); //turn off red led
            delay(blink[0]); //off for 500ms
        }
        //right -> Blue
            else if(touchVal>=1100){

            white_blink(2); //clear the white led off
            GPIOD->PCOR |= MASK(BLUE_LED_PIN); //turn on blue led
            delay(blink[count]); //blink in the array sequence
            GPIOD->PSOR |= MASK(BLUE_LED_PIN); //turn off blue led
            delay(blink[0]); //off for 500ms

        }
        //Center -> Green
            else if(touchVal>=500 && touchVal<=1100){

        	white_blink(2); //clear the white led off
            GPIOB->PCOR |= MASK(GREEN_LED_PIN); //turn on green led
            delay(blink[count]); //blink in the array sequence
            GPIOB->PSOR |= MASK(GREEN_LED_PIN); //turn off green led
            delay(blink[0]); //off for 500ms

        }
        count = count < 3? count+1 : 0; //looping the array delay sequence
   }
}
