/*
 * blinkled.c
 *
 */
#include "blinkled.h"
// Delay function produces a delay of time_ms.
void delay(int iterations)
{
    volatile int conversion = 0;
    conversion = iterations*2000; //correction to approximate delay time.
    while(conversion--);
    __asm volatile("NOP");
}
//Initializing the ports B and D to configure LEDS
void portInitialize(void)
{
    SIM->SCGC5 |= SIM_SCGC5_PORTB_MASK;
    SIM->SCGC5 |= SIM_SCGC5_PORTD_MASK;
}
//Initializing the pins 18, 16 of port B and 1 of port D to configure LEDS
void pinInitialize(void)
{
    GPIOB->PDOR |= MASK(RED_LED_PIN) | MASK(GREEN_LED_PIN);
    GPIOD->PDOR |= MASK(BLUE_LED_PIN);
    GPIOB->PDDR |= MASK(RED_LED_PIN) | MASK(GREEN_LED_PIN);
    GPIOD->PDDR |= MASK(BLUE_LED_PIN);
}
//Make 3 pins GPIO
void muxIntialize(void)
{
    PORTB->PCR[RED_LED_PIN] &= ~PORT_PCR_MUX_MASK;
    PORTB->PCR[RED_LED_PIN] |= PORT_PCR_MUX(1);
    PORTB->PCR[GREEN_LED_PIN] &= ~PORT_PCR_MUX_MASK;
    PORTB->PCR[GREEN_LED_PIN] |= PORT_PCR_MUX(1);
    PORTD->PCR[BLUE_LED_PIN] &= ~PORT_PCR_MUX_MASK;
    PORTD->PCR[BLUE_LED_PIN] |= PORT_PCR_MUX(1);
}
/*RGB LEDs on and off sequence:
case(1)-red on and off with delay
case(2)-green on and off with delay
case(3)-blue on and off with delay*/
void led_blink(int rgb)
{
switch(rgb)
{
	case (1):
		GPIOB->PCOR |= MASK(RED_LED_PIN); //on red led
        delay(ONTIME); //delay for 500ms
        GPIOB->PSOR |= MASK(RED_LED_PIN); //off red led
        delay(OFFTIME); //delay for 100ms
        break;
    case (2):
        GPIOB->PCOR |= MASK(GREEN_LED_PIN); //on green led
        delay(ONTIME); //delay for 500ms
        GPIOB->PSOR |= MASK(GREEN_LED_PIN); //off green led
        delay(OFFTIME); //delay for 100ms
        break;
    case (3):
		GPIOD->PCOR |= MASK(BLUE_LED_PIN); //on blue led
	    delay(ONTIME); //delay for 500ms
	    GPIOD->PSOR |= MASK(BLUE_LED_PIN); //off blue led
		delay(OFFTIME); //delay for 100ms
	    break;
	}
}
/* White led on and off sequence:
case(1)-white led on
case(2)-white led off
case(3)-white led on and off with delay*/
void white_blink(int led)
{
    switch(led)
    {
    case (1): //on white led
        GPIOB->PCOR |= MASK(RED_LED_PIN);
        GPIOB->PCOR |= MASK(GREEN_LED_PIN);
        GPIOD->PCOR |= MASK(BLUE_LED_PIN);
        break;
    case (2): //off white led
        GPIOB->PSOR |= MASK(RED_LED_PIN);
        GPIOB->PSOR |= MASK(GREEN_LED_PIN);
        GPIOD->PSOR |= MASK(BLUE_LED_PIN);
        break;
    case (3): //on white led with delay
        GPIOB->PCOR |= MASK(RED_LED_PIN);
        GPIOB->PCOR |= MASK(GREEN_LED_PIN);
        GPIOD->PCOR |= MASK(BLUE_LED_PIN);
        delay(ONTIME); //delay for 500ms
        GPIOB->PSOR |= MASK(RED_LED_PIN);
        GPIOB->PSOR |= MASK(GREEN_LED_PIN);
        GPIOD->PSOR |= MASK(BLUE_LED_PIN);
        delay(OFFTIME); //delay for 100ms
        break;
   }

}



